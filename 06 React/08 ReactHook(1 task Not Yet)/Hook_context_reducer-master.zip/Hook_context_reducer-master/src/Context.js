import React , {createContext}from 'react'

const Context = React.createContext(null)
export const Context2 = createContext(null)
export default Context
